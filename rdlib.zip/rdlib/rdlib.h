#ifndef RDLIB_H
#define RDLIB_H

int printf(const char *format, ...);

int scanf(const char *format, ...);

int GetLength(char *input) {
    int i = 0;
    while (input[i] != '\0') {
        i++;
    }
    return i;
}

#endif